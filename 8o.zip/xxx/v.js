(function () {

  var bv = new Bideo();
  bv.init({
    videoEl: document.querySelector('#background_video'),
    container: document.querySelector('body'),
    resize: true,
    autoplay: true,
    isMobile: window.matchMedia('(max-width: 2048px)').matches,
    playButton: document.querySelector('#play'),
    pauseButton: document.querySelector('#pause'),
    src: [
      {
        src: 'http://172.27.27.243/2TB1/Eng_Year_2018/Aquaman%20%282018%29/Aquamen.2018.1080p.HC.HDRip.X264-EVO.mkv',
        type: 'video/mp4'
      },
      {
        src: 'http://172.27.27.243/2TB1/Eng_Year_2018/Aquaman%20%282018%29/Aquamen.2018.1080p.HC.HDRip.X264-EVO.mkv',
        type: 'video/webm;codecs="vp8, vorbis"'
      }
    ],
    onLoad: function () {
      document.querySelector('#video_cover').style.display = 'none';
    }
  });
}());
