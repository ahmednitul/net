<?php
$links = array(

"https://img00.deviantart.net/9fe9/i/2012/035/e/b/wallpaper_by_kevelito-d4onvit.jpg",
"https://img00.deviantart.net/0297/i/2012/061/4/1/wallpaper_by_kevelito-d4rgcqn.jpg",
"https://pre00.deviantart.net/4ad4/th/pre/i/2011/116/7/2/gemma_atkinson_by_ultrainferno-d3eyc9o.jpg",
"https://img00.deviantart.net/5240/i/2011/141/7/c/wallpaper_2_by_ultrainferno-d3gvihu.jpg",
"https://pre00.deviantart.net/f1df/th/pre/f/2010/008/9/0/bianca_balti_by_m4rios.jpg",
"https://img00.deviantart.net/8de5/i/2011/252/4/2/hot_sexy_megan_fox_supermodel_by_delysidlsd-d49b0pf.jpg",
"https://pre00.deviantart.net/aa4e/th/pre/i/2011/107/8/1/sexy_ass_babe_by_mistershyn-d3e8fs0.jpg",
"https://pre00.deviantart.net/8386/th/pre/f/2007/109/9/a/hot_babe_1280x800_by_sabishine.jpg",
"https://pre00.deviantart.net/9667/th/pre/f/2013/249/0/d/malena_morgan__06september2013friday___193552__by_jerry111251-d6l8s3l.jpg",
"https://pre00.deviantart.net/3e60/th/pre/f/2015/237/4/c/beach_babe_05_by_speedz0r-d973oav.jpg",
"https://pre00.deviantart.net/8472/th/pre/f/2015/249/9/e/pool_babe_01_by_speedz0r-d98l2o2.jpg",
"https://pre00.deviantart.net/a814/th/pre/f/2015/249/7/4/beach_babe_06_by_speedz0r-d98l0b6.jpg",
"https://orig00.deviantart.net/7aa8/f/2014/307/1/2/doutzen_kroes_sexy_wallpaper_doutzen_kroes_babes_g_by_kristensen001-d854orw.jpg",
"https://pre00.deviantart.net/fa38/th/pre/f/2015/025/2/8/sexy_babe_wallpaper_1920x1080_by_sachso74-d8fcvre.jpg",
"https://pre00.deviantart.net/916d/th/pre/f/2013/259/4/5/amazing_babe__79__jessica_pace__26april2013friday__by_jerry111251-d6mmklw.jpg",

);

$rr = $links[array_rand($links)];
header("Location: $rr");
?>